/*
 * Copyright (C) 2018 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mapclient.liteapp;

import android.app.Application;

public class ONApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
