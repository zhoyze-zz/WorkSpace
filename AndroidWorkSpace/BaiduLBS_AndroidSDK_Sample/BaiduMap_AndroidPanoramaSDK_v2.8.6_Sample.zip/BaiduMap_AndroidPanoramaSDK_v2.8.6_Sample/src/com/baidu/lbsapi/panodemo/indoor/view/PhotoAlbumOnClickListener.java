package com.baidu.lbsapi.panodemo.indoor.view;

import com.baidu.lbsapi.panodemo.indoor.model.AlbumPicInfo;

public interface PhotoAlbumOnClickListener {
    void onItemClicked(AlbumPicInfo picInfo);
}